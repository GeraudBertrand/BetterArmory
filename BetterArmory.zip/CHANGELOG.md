 `1.0.2`

-    ***FIXED CONTENT***

    - Blood Rage pickup model error was change to correct prefab.

    - Change description of item to a more correct language (always seek suggestion)
