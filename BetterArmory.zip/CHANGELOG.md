 `1.0.2`

-    ***FIXED CONTENT***
    - Queron Contract error on Sucide, verify the attacker now to only execute if there is an attacker
